// netlify/functions/create-subscription.js
const stripe = require('stripe')(process.env.REACT_APP_STRIPE_SECRET_KEY);

exports.handler = async (event) => {
    if (event.httpMethod !== 'POST') {
        console.log(event.httpMethod)
        return { statusCode: 405, body: 'Method Not Allowed' };
    }

    try {
        console.log(event.body);
        
        const { priceId, userId } = JSON.parse(event.body);

        const session = await stripe.checkout.sessions.create({
            mode: 'subscription',
            payment_method_types: ['card'],
            line_items: [
                {
                    price: priceId,
                    quantity: 1,
                },
            ],
            success_url: `${process.env.URL}/success?session_id={CHECKOUT_SESSION_ID}`,
            cancel_url: `${process.env.URL}/cancel`,
            client_reference_id: userId,
        });

        return {
            statusCode: 200,
            body: JSON.stringify({ id: session.id }),
        };
    } catch (error) {
        console.log(error);
        
        return {
            statusCode: 400,
            body: JSON.stringify({ error: error.message }),
        };
    }
};